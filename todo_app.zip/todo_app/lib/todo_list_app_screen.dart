import 'package:flutter/material.dart';
import 'package:todo_app/task_model.dart';

class TodoListAppScreen extends StatefulWidget {
  const TodoListAppScreen({super.key});

  @override
  State<TodoListAppScreen> createState() => _TodoListAppScreenState();
}

class _TodoListAppScreenState extends State<TodoListAppScreen> {
  final List<Task> tasks = [];
  final TextEditingController titleController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  void _addTask({
    required String title,
    required String description,
  }) {
    setState(() {
      tasks.add(Task(
        title: title,
        description: description,
      ));
    });
  }

  void _taskCompletion(int index) {
    setState(() {
      tasks[index].isCompleted = !tasks[index].isCompleted;
    });
  }

  void _deleteTask(int index) {
    setState(() {
      tasks.removeAt(index);
    });
  }

  void _editTask(int index, String newTitle, String newDescription) {
    setState(() {
      tasks[index].title = newTitle;
      tasks[index].description = newDescription;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TodoApp'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(
                labelText: 'Title',
              ),
            ),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description',
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: ElevatedButton(
                onPressed: () {
                  if (titleController.text.isNotEmpty &&
                      descriptionController.text.isNotEmpty) {
                    _addTask(
                        title: titleController.text,
                        description: descriptionController.text);
                  }
                  titleController.clear();
                  descriptionController.clear();
                },
                child: const Text('Add Task'),
              ),
            ),
            Expanded(
              child: ListView.builder(
                  itemCount: tasks.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(
                        tasks[index].title,
                      ),
                      subtitle: Text(
                        tasks[index].description,
                      ),
                      leading: Checkbox(
                        value: tasks[index].isCompleted,
                        onChanged: (value) {
                          _taskCompletion(index);
                        },
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            onPressed: () {
                              _editTask(index, 'new title', 'new description');
                            },
                            icon: const Icon(
                              Icons.edit,
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              _deleteTask(index);
                            },
                            icon: const Icon(
                              Icons.delete,
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
